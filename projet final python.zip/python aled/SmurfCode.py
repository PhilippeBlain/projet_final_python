# -*- coding: utf-8 -*-
"""
Created on Tue Apr 26 17:14:41 2022

@author: fifib
"""


import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap
from PyQt5 import QtCore
import dbm
import os
import paramiko
from History import HistoryFenetre

class SmurfFenetre(QWidget):
    def __init__(self, previous):
        
        
        super().__init__()
        
        
        
        self.setFixedWidth(500)
        self.setFixedHeight(400)
  
        

        self.nom1 = QLabel("Nom")
        self.nom2 = QLineEdit("")

        self.prenom1 = QLabel("Prenom")
        self.prenom2 = QLineEdit("")
        
        self.Age1 = QLabel("Date de naissance")
        self.Age2 = QLineEdit("")
        
        self.sexe1 = QLabel("Sexe")
        self.sexe2 = QRadioButton("M")
        self.sexe3 = QRadioButton("F")
        
        self.symptomes = QTextEdit("")
        self.symptomes.setMinimumHeight(200)
        
        self.medicaments = QTextEdit("")
        self.medicaments.setReadOnly(True)
        self.medicaments.setMinimumHeight(200)
        self.medicaments.setMinimumWidth(200)
        
        self.save = QPushButton("Enregistrer")
        self.save.setToolTip('Cliquez pour sauvegader')
        
        self.historique = QPushButton("Historique")
        self.historique.setToolTip("Cliquez pour acceder a l'historique")
        
        self.retour = QPushButton("Retour")
        self.retour.setToolTip('Cliquez pour revenir sur la page precedente')
        
    
        
        
        self.init_smurf()
        self.previous = previous
        
        


    def init_smurf(self):
        
        h_box = QHBoxLayout()
        h_box.addWidget(self.sexe2)
        h_box.addWidget(self.sexe3)
        
        
        grid = QGridLayout()
        grid.addWidget(self.nom1, 0,0)
        grid.addWidget(self.nom2, 0,1)
        grid.addWidget(self.prenom1, 1,0)
        grid.addWidget(self.prenom2, 1,1)
        grid.addWidget(self.Age1, 2,0)
        grid.addWidget(self.Age2, 2,1)
        grid.addWidget(self.sexe1, 3,0)
        grid.addLayout(h_box, 3,1)
        grid.addWidget(self.symptomes, 4,0, 1,2)
        grid.addWidget(self.save, 5,0, 1,2)
        grid.addWidget(self.historique, 1,3, 1,2)
        grid.addWidget(self.medicaments, 4,3, 1,2)
        grid.addWidget(self.retour, 5,3, 1,2)
       
        
        
       
        
        
        self.setLayout(grid)
        self.setWindowTitle('Sphynx')
        
        self.retour.clicked.connect(self.fermer)
        self.save.clicked.connect(self.enregistrer)
        self.historique.clicked.connect(self.histo)
        
    def fermer(self) :
        self.hide()
        self.previous.show()
        
    def enregistrer(self):
    
        
        
        
        nomVar = str(self.nom2.text())
        prenomVar = str(self.prenom2.text())    
        ageVar = str(self.Age2.text())
        symp = str(self.symptomes.toPlainText())
        
        if self.sexe2.isChecked():
            sexeVar = "Homme"
        if self.sexe3.isChecked():
            sexeVar = "Femme"
        key = nomVar + " " + prenomVar +  " " + ageVar + " " + sexeVar 
        
        dbDoss = dbm.open('Dossier', 'c')
        dbDoss[key]= symp
        
        sftp.put('Dossier.dat', '/home/etudiant/Dossier.dat')
        sftp.put('Dossier.dir', '/home/etudiant/Dossier.dir')
        sftp.put('Dossier.bak', '/home/etudiant/Dossier.bak')
        
       
        
        
    def histo(self):
        nomVar = str(self.nom2.text())
        prenomVar = str(self.prenom2.text())    
        ageVar = str(self.Age2.text())
        anciensymp = ""
        
        if self.sexe2.isChecked():
            sexeVar = "male"
        if self.sexe3.isChecked():
            sexeVar = "femelle"
        
        
        dbDoss = dbm.open('Dossier', 'c')
        key = nomVar + " " + prenomVar +  " " + ageVar + " " + sexeVar 
        for cle, value in dbDoss.items():
            if(cle == key):
                key = key + " " + value
        L = key.split()
               
        print(L)
        self.fenetre3 = HistoryFenetre(self, L)
        self.fenetre3.show()
        
        
        
        
s = paramiko.SSHClient()
s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
s.connect("192.168.141.181",22,username="etudiant",password='vitrygtr',timeout=4)
sftp = s.open_sftp()
dbDoss = dbm.open('Dossier' , 'n')


sftp.chdir("/home/etudiant/")
try:
    sftp.stat('/home/etudiant/Dossier.dat')
    sftp.get('/home/etudiant/Dossier.dat', 'Dossier.dat' )
    sftp.stat('/home/etudiant/DBpoids.dir')
    sftp.get('/home/etudiant/Dossier.dir', 'Dossier.dir' )
    sftp.stat('/home/etudiant/Dossier.bak')
    sftp.get('/home/etudiant/Dossier.bak', 'Dossier.bak' )
    sftp.stat('/home/etudiant/Dossier.dat')
except IOError:
    print('files do not exist')