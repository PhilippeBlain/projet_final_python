# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 12:43:24 2022

@author: fifib
"""

import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap
from PyQt5 import QtCore
import dbm
import os

class HistoryFenetre(QWidget):
    def __init__(self, ancient, liste):
        
        
        super().__init__()
        self.setFixedWidth(500)
        self.setFixedHeight(400)
  
        

        self.nom1 = QLabel("Nom")
        self.nom2 = QLineEdit(liste[0])

        self.prenom1 = QLabel("Prenom")
        self.prenom2 = QLineEdit(liste[1])
        
        self.Age1 = QLabel("Date de naissance")
        self.Age2 = QLineEdit(liste[2])
        
        self.sexe1 = QLabel("Sexe")
        self.sexe2 = QLineEdit(liste[3])
        
        
        self.medicaments = QTextEdit("")
        self.medicaments.setReadOnly(True)
        
        self.nom2.setReadOnly(True)
        self.prenom2.setReadOnly(True)
        self.Age2.setReadOnly(True)
        self.sexe2.setReadOnly(True)
        
        self.medicaments.setMinimumHeight(100)
        self.medicaments.setMinimumWidth(200)
        
        self.retour = QPushButton("Retour")
        self.retour.setToolTip('Cliquez pour revenir sur la page precedente')
        
    
        
        
        self.init_history()
        self.ancient = ancient
        
    def init_history(self):
        
        
        
        
        grid = QGridLayout()
        grid.addWidget(self.nom1, 0,0)
        grid.addWidget(self.nom2, 0,1)
        grid.addWidget(self.prenom1, 1,0)
        grid.addWidget(self.prenom2, 1,1)
        grid.addWidget(self.Age1, 2,0)
        grid.addWidget(self.Age2, 2,1)
        grid.addWidget(self.sexe1, 3,0)
        grid.addWidget(self.sexe2, 3,1, 1,2)
        

        grid.addWidget(self.medicaments, 4,0, 1,3)
        grid.addWidget(self.retour, 5,3, 1,2)
       
        
        
       
        
        
        self.setLayout(grid)
        self.setWindowTitle('Sphynx')
        self.retour.clicked.connect(self.close)
        
    def close(self):
        self.hide()
        