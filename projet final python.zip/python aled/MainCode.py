# -*- coding: utf-8 -*-
"""
Created on Tue Apr 26 14:53:05 2022

@author: fifib
"""

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap
from PyQt5 import QtCore
import dbm
import os
import paramiko
from SmurfCode import SmurfFenetre

class IHM(QWidget):
    def __init__(self):
        super().__init__()
        
        self.fenetre2 = SmurfFenetre(self)
        
        self.setGeometry(200, 200, 400, 400)
        self.setFixedWidth(400)
        self.setFixedHeight(400)
        
        
        self.image = QLabel(self)
        self.image.setGeometry(150,50,100,100)
        self.image.setScaledContents(True)
        pixmap = QPixmap('Chat2.png')
        self.image.setPixmap(pixmap)

        self.text1 = QLabel("Sphynx")
        self.text1.setAlignment(QtCore.Qt.AlignCenter)
        self.text2 = QLabel("Bienvenue")
        self.text2.setAlignment(QtCore.Qt.AlignCenter)
        
        
        self.butt1 = QPushButton('Créer un dossier')
        self.butt1.setToolTip('Cliquez pour créer un dossier')
        self.butt1.setStyleSheet ("background-color: grey; border-radius: 1px")
        
        self.butt2 = QPushButton('Importer un dossier')
        self.butt2.setToolTip('Cliquez pour impoter un dossier')
        self.butt2.setStyleSheet ("background-color: grey; border-radius: 1px")
        self.init_ui()
        self.show()

    def init_ui(self):
        v_box = QVBoxLayout()
        v_box.addWidget(self.image)
        v_box.addWidget(self.text1)
        v_box.addWidget(self.text2)
        v_box.addWidget(self.butt1)
        v_box.addWidget(self.butt2)
        
        self.setLayout(v_box)
        self.setWindowTitle('Sphynx')
        
        self.butt1.clicked.connect(self.creer_doss)
        self.butt2.clicked.connect(self.import_doss)
        
    def creer_doss(self) :
        self.hide()
        self.fenetre2.show()
    def import_doss(self) :
        name = input("Entrez le nom du dossier : ")
        

        
   
app = QApplication(sys.argv)
interface = IHM()
sys.exit(app.exec_())